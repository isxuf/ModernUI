# Theme resource reference

The complete list of theme resources.

**Note**: keep in mind that Modern UI is in beta and work in progress. Resources may be added and removed in the future.

|| Resource || Type || Light default || Dark default ||
| ButtonBackground | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff333333.png) #FF333333 |
| ButtonBackgroundHover | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| ButtonBackgroundPressed | Brush | {AccentColor} | {AccentColor} |
| ButtonBorder | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| ButtonBorderHover | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| ButtonBorderPressed | Brush | {AccentColor} | {AccentColor} |
| ButtonText | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ButtonTextDisabled | Brush | ![](Theme resource reference_ffa1a1a1.png) #FFA1A1A1 | ![](Theme resource reference_ff515151.png) #FF515151 |
| ButtonTextHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ButtonTextPressed | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridBackground | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| DataGridCellBackground | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| DataGridCellBackgroundHover | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| DataGridCellBackgroundSelected | Brush | {AccentColor} | {AccentColor} |
| DataGridCellForeground | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridCellForegroundHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridCellForegroundSelected | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridDropSeparator | Brush | {AccentColor} | {AccentColor} |
| DataGridForeground | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridGridLines | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| DataGridHeaderBackground | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| DataGridHeaderBackgroundHover | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| DataGridHeaderBackgroundPressed | Brush | {AccentColor} | {AccentColor} |
| DataGridHeaderBackgroundSelected | Brush | {AccentColor} | {AccentColor} |
| DataGridHeaderForeground | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridHeaderForegroundHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridHeaderForegroundPressed | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| DataGridHeaderForegroundSelected | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| Hyperlink | Brush | {AccentColor} | {AccentColor} |
| HyperlinkDisabled | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff717171.png) #FF717171 |
| HyperlinkHover | Brush | {AccentColor} | {AccentColor} |
| InputBackground | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff333333.png) #FF333333 |
| InputBackgroundHover | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| InputBorder | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| InputBorderHover | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| InputText | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| InputTextDisabled | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff717171.png) #FF717171 |
| InputTextHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ItemBackgroundHover | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| ItemBackgroundSelected | Brush | {AccentColor} | {AccentColor} |
| ItemBorder | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| ItemText | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ItemTextDisabled | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff717171.png) #FF717171 |
| ItemTextHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ItemTextSelected | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| LinkButtonText | Brush | ![](Theme resource reference_ff717171.png) #FF717171 | ![](Theme resource reference_ff717171.png) #FF717171 |
| LinkButtonTextDisabled | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff515151.png) #FF515151 |
| LinkButtonTextHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| LinkButtonTextPressed | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff515151.png) #FF515151 |
| MenuText | Brush | ![](Theme resource reference_66000000.png) #66000000 | ![](Theme resource reference_ff515151.png) #FF515151 |
| MenuTextHover | Brush | ![](Theme resource reference_bb000000.png) #BB000000 | ![](Theme resource reference_ff919191.png) #FF919191 |
| MenuTextSelected | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ModernButtonBorder | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff919191.png) #FF919191 |
| ModernButtonBorderDisabled | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff515151.png) #FF515151 |
| ModernButtonBorderHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ModernButtonBorderPressed | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ModernButtonIconBackgroundPressed | Brush | {AccentColor} | {AccentColor} |
| ModernButtonIconForegroundPressed | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ModernButtonText | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ModernButtonTextDisabled | Brush | ![](Theme resource reference_ffa1a1a1.png) #FFA1A1A1 | ![](Theme resource reference_ff515151.png) #FF515151 |
| ModernButtonTextHover | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ModernButtonTextPressed | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| PopupBackground | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff252526.png) #FF252526 |
| ProgressBackground | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_ff333333.png) #FF333333 |
| ScrollBarBackground | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_ff333333.png) #FF333333 |
| ScrollBarThumbBackground | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| ScrollBarThumbBackgroundDragging | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| ScrollBarThumbBackgroundHover | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| ScrollBarThumbBorder | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| ScrollBarThumbForeground | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_ff717171.png) #FF717171 |
| ScrollBarThumbForegroundDragging | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| ScrollBarThumbForegroundHover | Brush | ![](Theme resource reference_00ffffff.png) #00FFFFFF | ![](Theme resource reference_ff919191.png) #FF919191 |
| SeparatorBackground | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff3e3e42.png) #FF3E3E42 |
| SliderSelectionBackground | Brush | {AccentColor} | {AccentColor} |
| SliderSelectionBorder | Brush | {AccentColor} | {AccentColor} |
| SliderThumbBackground | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff717171.png) #FF717171 |
| SliderThumbBackgroundDisabled | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| SliderThumbBackgroundDragging | Brush | {AccentColor} | {AccentColor} |
| SliderThumbBackgroundHover | Brush | ![](Theme resource reference_ffdddddd.png) #FFDDDDDD | ![](Theme resource reference_ff919191.png) #FF919191 |
| SliderThumbBorder | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff717171.png) #FF717171 |
| SliderThumbBorderDisabled | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| SliderThumbBorderDragging | Brush | {AccentColor} | {AccentColor} |
| SliderThumbBorderHover | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff919191.png) #FF919191 |
| SliderTick | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff717171.png) #FF717171 |
| SliderTickDisabled | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| SliderTrackBackground | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| SliderTrackBorder | Brush | ![](Theme resource reference_ffcccccc.png) #FFCCCCCC | ![](Theme resource reference_ff333333.png) #FF333333 |
| SubMenuText | Brush | ![](Theme resource reference_99000000.png) #99000000 | ![](Theme resource reference_ff717171.png) #FF717171 |
| SubMenuTextHover | Brush | ![](Theme resource reference_66000000.png) #66000000 | ![](Theme resource reference_ff515151.png) #FF515151 |
| SubMenuTextSelected | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffd1d1d1.png) #FFD1D1D1 |
| WindowBackground | Brush | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff252526.png) #FF252526 |
| WindowBackgroundColor | Color | ![](Theme resource reference_ffffffff.png) #FFFFFFFF | ![](Theme resource reference_ff252526.png) #FF252526 |
| WindowBackgroundContent | UIElement | Rectangle | Rectangle |
| WindowBorder | Brush | {AccentColor} | {AccentColor} |
| WindowBorderActive | Brush | {AccentColor} | {AccentColor} |
| WindowHeaderGradient | Brush | LinearGradientBrush | ![](Theme resource reference_00ffffff.png) #00FFFFFF |
| WindowText | Brush | ![](Theme resource reference_ff333333.png) #FF333333 | ![](Theme resource reference_ffc1c1c1.png) #FFC1C1C1 |
| WindowTextReadOnly | Brush | ![](Theme resource reference_ff919191.png) #FF919191 | ![](Theme resource reference_ff717171.png) #FF717171 |

