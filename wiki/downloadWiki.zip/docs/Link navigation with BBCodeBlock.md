# Link navigation with BBCodeBlock

The BBCodeBlock control is used for simple rich text formatting and includes support for link navigation. Link navigation is performed by an instance of **ILinkNavigator** assigned to the BBCodeBlock.LinkNavigator property. The default value is an instance of **DefaultLinkNavigator**. DefaultLinkNavigator supports navigation to external urls, internal pages and command execution.

## External navigation
An absolute url with scheme http, https and mailto is opened in the default browser when clicked.

{code:xml}
<mui:BBCodeBlock BBCode="[url=http://www.google.com](url=http___www.google.com)go to google[/url](_url)" />
{code:xml}
## Internal navigation
Relative urls are by default opened in the same **ModernFrame** instance that is hosting the BBCodeBlock defining the link. Selecting the following link will cause the ModernFrame to load the XAML page _/Pages/MyPage.xaml_.

{code:xml}
<mui:BBCodeBlock BBCode="[url=/Pages/MyPage.xaml](url=_Pages_MyPage.xaml)go to my page[/url](_url)" />
{code:xml}
When navigating to an internal page, you can specify the target frame. The target frame is set by appending a '|' character to the url followed by the frame name.  The following target names are supported:
* **_self**, loads the page in the same frame where the BBCodeBlock resides. This effectively replaces the current page. 
* **_parent**, load the page in the parent frame
* **_top**, loads the page in the top most frame found in the application. This is usually the **ModernFrame** instance defined in the **ModernWindow** template.
* **(name)**: loads the page in the frame having specified name
The following link loads the XAML page in the top-most frame.

{code:xml}
<mui:BBCodeBlock BBCode="[url=/Pages/MyPage.xaml](_top)go to my page[/url](_url)" />
{code:xml}
## Executing commands
BBCodeBlock links can also be used to trigger the execution of an **ICommand** instance. To add support for command links, the command need to be registered with the **ILinkNavigator** instance associated with the BBCodeBlock. The ILinkNavigator interface includes a **Commands** property of type **CommandCollection** that is used to map a command to a uri.

Links that refer to registered commands are automatically enabled and disabled based on the CanExecute state of the ICommand.

The following XAML snippet registers a custom command and defines a link that executes the command when clicked.

{code:xml}
<mui:BBCodeBlock BBCode="[url=cmd://mycommand](url=cmd___mycommand)execute my command[/url](_url)">
  <mui:BBCodeBlock.LinkNavigator>
    <mui:DefaultLinkNavigator>
      <mui:DefaultLinkNavigator.Commands>
        <sample:MyCommand x:Key="cmd://mycommand" />
      </mui:DefaultLinkNavigator.Commands>
    </mui:DefaultLinkNavigator>
  </mui:BBCodeBlock.LinkNavigator>
</mui:BBCodeBlock>
{code:xml}
You can supply a command parameter by appending a '|' character and adding a parameter value. Please note that the parameter value may not contain whitespace characters and should be url encoded.

The following link executes a custom command while providing the command parameter string value 'my parameter';

{code:xml}
<mui:BBCodeBlock BBCode="[url=cmd://mycommand](my%20parameter)execute my command[/url](_url)" />
{code:xml}

For more details on implementing ICommand and registering it for use in a BBCodeBlock see  [discussion:441838](discussion_441838).

