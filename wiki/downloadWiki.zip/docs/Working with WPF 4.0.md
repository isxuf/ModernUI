# Working with WPF 4.0

Modern UI targets both WPF 4.0 and 4.5. The download package contains assemblies for both WPF versions. When you use [NuGet](http://nuget.org/packages/ModernUI.WPF/), the correct WPF version is automatically selected based on the target framework of your project. The Visual Studio 2012 templates however only work for WPF 4.5.

There is one workaround required in WPF 4.0 for control styling to work correctly. Make sure you add an empty style for a rectangle in your App.xaml.

{code:xml}
<Application.Resources>
<ResourceDictionary>
<!-- WPF 4.0 workaround -->
<Style TargetType="{x:Type Rectangle}" />
<!-- end of workaround -->
<ResourceDictionary.MergedDictionaries>
  <ResourceDictionary Source="/FirstFloor.ModernUI;component/Assets/ModernUI.xaml" />
  <ResourceDictionary Source="/FirstFloor.ModernUI;component/Assets/ModernUI.Light.xaml"/>
</ResourceDictionary.MergedDictionaries>
</ResourceDictionary>
</Application.Resources>
{code:xml}

