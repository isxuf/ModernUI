# Why BBCode?

What's the deal with this BBCodeBlock? Why use BBCode? It's an outdated markup language! Isn't that what XAML is for? 

Good question! There are two main reasons to introduce a text markup language next to XAML.

## 1: BBCode is lightweight
Try to model the following really simple rich text in XAML and compare it to the BBCode equivalent.

This is a **text** _sample_ with +some basic+ formatting.

**XAML**
{code:xml}
<TextBlock>
  <Run Text="This is a" />
  <Run Text="text" FontWeight="Bold" />
  <Run Text="sample" FontStyle="Italic" />
  <Run Text="with" />
  <Run Text="some basic" TextDecorations="Underline" />
  <Run Text="formatting." />
</TextBlock>
{code:xml}
**BBCode**
{code:xml}
<mui:BBCodeBlock BBCode="This is a [b](b)text[/b](_b) [i](i)sample[/i](_i) with [u](u)some basic[/u](_u) formatting." />
{code:xml}
That is only one single line of BBCode! A single string value fully describes the rich text. This also opens up ways in MVVM to expose bindable rich text messages in a view model using string data only. You wouldn't want your ViewModel to produce XAML elements for that.

## 2) Enabling efficient and customizable link navigation
What if you want to add a hyperlink to your page that navigates to an external url? You can't simply solve this in XAML alone, you need to either implement an ICommand and assign it to your Hyperlink instance, or you need to add code in the code-behind file (assuming you are not building a XBAP app). With **ILinkNavigator**, link navigation becomes super easy in a BBCodeBlock. The following snippet is all that is required to show a link that opens a uri in the default browser with a BBCodeBlock.

{code:xml}
<mui:BBCodeBlock BBCode="[url=http://www.google.com](url=http___www.google.com)go to google[/url](_url)" />
{code:xml}
There is a tutorial ([Link navigation with BBCodeBlock](Link-navigation-with-BBCodeBlock)) with detailed information on internal and external page navigation and command execution.

And don't worry about performance, BBCodeBlock is fast. The included BBCodeParser is efficient, BBCode blocks are parsed in (fractions of) milliseconds.

