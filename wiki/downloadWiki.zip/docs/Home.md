# MUI has moved to GitHub
Go to **[https://github.com/firstfloorsoftware/mui](https://github.com/firstfloorsoftware/mui)** for the latest updates on MUI. This CodePlex project is no longer maintained. 
