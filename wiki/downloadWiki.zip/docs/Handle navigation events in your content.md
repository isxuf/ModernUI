# Handle navigation events in your content

Modern UI includes a content navigation framework that handles content loading, unloading and history navigation based on link uris. If you want your content to be aware of navigation events such as loaded and unloaded events, you'll need to implement an interface.

Make your content navigation aware by implementing the **IContent** interface available in the **FirstFloor.ModernUI.Windows** namespace. The interface defines 4 methods:

{code:c#}
public interface IContent
{
  void OnFragmentNavigation(FragmentNavigationEventArgs e);
  void OnNavigatedFrom(NavigationEventArgs e);
  void OnNavigatedTo(NavigationEventArgs e);
  void OnNavigatingFrom(NavigatingCancelEventArgs e);
}
{code:c#}

## Loading and unloading
The _OnNavigatedTo_ method is invoked when the content becomes the active content in a frame. This is a good time to initialize your content.

The _OnNavigatingFrom_ method is invoked when the content is about to become inactive. You can use the _OnNavigatingFrom_ method to cancel navigation by setting the **NavigatingCancelEventArgs.Cancel** to true. The method _OnNavigatedFrom_ is called when the content is no longer the active content.

| **Important**: do not rely on WPF _Loaded_ and _Unloaded_ events for content initialization and clean up. The _Loaded_ and _Unloaded_ events are raised multiple times when the active content changes. This is due to the use of multiple ContentPresenters in the TransitioningContentControl required for fluent animations. Use _OnNavigatedTo_ and _OnNavigatedFrom_ instead. |
## Fragment navigation
The _OnFragmentNavigation_ is called when navigation to a content fragment begins. Fragment navigation happens when you navigate to a link uri containing a fragment (use the **#** character).

Once **IContent** is implemented by your content pages, the navigation methods are automatically invoked when a page is loaded in a ModernFrame instance. The following code demonstrates a content sample that prevents navigation when the user doesn't allow it:

{code:c#}
public class MyContent : UserControl, IContent
{
  public void OnFragmentNavigation(FragmentNavigationEventArgs e)
  {
  }
  public void OnNavigatedFrom(NavigationEventArgs e)
  {
  }
  public void OnNavigatedTo(NavigationEventArgs e)
  {
  }
  public void OnNavigatingFrom(NavigatingCancelEventArgs e)
  {
    // ask user if navigating away is ok
    if (false == ModernDialog.ShowMessage("Navigate away?, "navigate",   
      System.Windows.MessageBoxButton.YesNo)) {
                e.Cancel = true;
    }
  }
}
{code:c#}
