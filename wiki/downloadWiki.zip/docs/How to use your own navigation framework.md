# How to use your own navigation framework

Modern UI for WPF comes with a built-in page navigation framework. It is easy-to-use and extensible. You are however not required to use the built-in framework, you can roll your own just as easily.

The default ModernWindow control template includes title, menu and back controls to support the page navigation framework. The ModernWindow.Content property is ignored and not rendered at all in the default template. If you choose to use you own navigation framework, you probably want to render your own controls. This can be achieved by using a custom ModernWindow style that is blank and can be filled by setting the ModernWindow.Content.

The empty ModernWindow style is available in the Modern UI assets with resource key **BlankWindow**.

This is how you would use the style in XAML:

{code:xml}
<mui:ModernWindow x:Class="ModernUIApp7.MainWindow"
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    xmlns:mui="http://firstfloorsoftware.com/ModernUI"
    Title="MainWindow"
    Style="{StaticResource BlankWindow}">
  <Grid>
    <TextBlock Text="Content goes here" />
  </Grid>
</mui:ModernWindow>
{code:xml}
And here's how to create an blank ModernWindow in code:

{code:c#}
var wnd = new ModernWindow {
  Style = (Style)App.Current.Resources["BlankWindow"](_BlankWindow_),
  Content = null	 // your content here
};
wnd.Show();
{code:c#}

| **Important**: Please note that the ModernWindow _ContentSource_, _MenuGroupLinks_, _TitleLinks_ and _LogoData_ properties are no longer used when using the BlankWindow style. Since you're implementing your own navigation framework, you'll need to provide the controls for it yourself. |

