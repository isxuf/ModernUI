# MUI has moved to GitHub
Go to **[GitHub](https://github.com/firstfloorsoftware/mui)**. This documentation is no longer maintained

# My first Modern UI app

Creating a Modern UI app manually from scratch. For a step-by-step tutorial on creating a Modern UI app using project and item templates see [My first Modern UI app using templates](My-first-Modern-UI-app-using-templates)

1) Get the latest ModernUI release and unzip its contents to disk or install the [ModernUI.WPF](http://nuget.org/packages/ModernUI.WPF/) package using NuGet.
2) Open Visual Studio and create a new WPF Application project
3) Add an assembly reference to **FirstFloor.ModernUI.dll** (for WPF4 projects you need to add an additional reference to **Microsoft.Windows.Shell.dll**).
4) Derive MainWindow from **ModernWindow**

Open MainWindow.xaml, add the ModernUI xmlns declaration and replace the Window element with mui:ModernWindow as shown below:
{code:xml}
<mui:ModernWindow x:Class="MuiTest.MainWindow"
  xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
  xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
  xmlns:mui="http://firstfloorsoftware.com/ModernUI"
  Title="MainWindow" Height="350" Width="525">
</mui:ModernWindow>
{code:xml}
Open The MainWindow.xaml.cs, add the ModernUI using and replace the Window base class with ModernWindow.
{code:c#}
using FirstFloor.ModernUI.Windows.Controls;
public partial class MainWindow : ModernWindow {  ..  }
{code:c#}
5) Open App.xaml and add the following resource dictionary references.

{code:xml}
<Application.Resources>
<ResourceDictionary>
<ResourceDictionary.MergedDictionaries>
  <ResourceDictionary Source="/FirstFloor.ModernUI;component/Assets/ModernUI.xaml" />
  <ResourceDictionary Source="/FirstFloor.ModernUI;component/Assets/ModernUI.Light.xaml"/>
</ResourceDictionary.MergedDictionaries>
</ResourceDictionary>
</Application.Resources>
{code:xml}
Choose **ModernUI.Light.xaml** for the light theme and **ModernUI.Dark.xaml** for the dark theme. Don't supply both at the same time!

| **Important**: If you are using the **WPF 4.0** version of ModernUI you need to add an empty Rectangle style to work around a bug in WPF, as shown below. The workaround is not needed for WPF 4.5 |
{code:xml}
<Application.Resources>
<ResourceDictionary>
<!-- WPF 4.0 workaround -->
<Style TargetType="{x:Type Rectangle}" />
<!-- end of workaround -->
<ResourceDictionary.MergedDictionaries>
  <ResourceDictionary Source="/FirstFloor.ModernUI;component/Assets/ModernUI.xaml" />
  <ResourceDictionary Source="/FirstFloor.ModernUI;component/Assets/ModernUI.Light.xaml"/>
</ResourceDictionary.MergedDictionaries>
</ResourceDictionary>
</Application.Resources>
{code:xml}

6) Compile and run the application. You should see the following window;

![](My first Modern UI app_ModernWindow.Empty.png)

7) Go back to MainWindow.xaml and remove the <Grid></Grid content

**Important**: the ModernWindow.Content property is ignored, all content is rendered by specifying page links as is demonstrated below.

8) Let's define the main menu. Add the following menu link groups:

{code:xml}
<mui:ModernWindow.MenuLinkGroups>
  <mui:LinkGroup DisplayName="group 1" >
    <mui:LinkGroup.Links>
      <mui:Link DisplayName="link 1" />
      <mui:Link DisplayName="link 2" />
      <mui:Link DisplayName="link 3" />
    </mui:LinkGroup.Links>
  </mui:LinkGroup>
</mui:ModernWindow.MenuLinkGroups>
{code:xml}
9) Compile and run the application. You should see the following window;

![](My first Modern UI app_ModernWindow.Menu.png)

10) Let's add some actual content. Add a WPF UserControl named Page1

11) Open Page1.xaml and add the following content
{code:xml}
<Grid Style="{StaticResource ContentRoot}">
  <TextBlock Text="Hello Modern UI!" />
</Grid>
{code:xml}
The ContentRoot style ensures the content is correctly positioned on screen.

12) Go back to MainWindow.xaml and modify the first link so that it refers to Page1.xaml
{code:xml}
<mui:Link DisplayName="link 1" Source="/Page1.xaml" />
{code:xml}
13) Additionally add a ContentSource attribute to the ModernWindow element
{code:xml}
<mui:ModernWindow ...
  ContentSource="/Page1.xaml"
 />
{code:xml}
The ContentSource defines the page that is loaded on start. In above case, /Page1.xaml will be loaded upon startup.

14) Compile and run the application. You should see the following window;

![](My first Modern UI app_ModernWindow.FirstPage.png)

And that's it. You can now add additional groups and links in the MenuLinkGroups and refer to the various pages in your application. For further details on defining your MetroWindow content see the other tutorials.