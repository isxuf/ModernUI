# BBCode tag reference

The following basic set of BBCode tags are supported by the **BBCodeBlock** control. If you require more advanced text formatting features, you need to fallback to using XAML.

|| Tag || Description ||
| **{"[b](b)"}** | Bold |
| **{"[i](i)"}** | Italic |
| **{"[u](u)"}** | Underline |
| **{"[color={value}](color={value})"}** | Set foreground color where {value} is a valid XAML color string |
| **{"[size={value}](size={value})"}** | Sets the font size measured in pixels |
| **{"[url={link}](url={link})"}** | Renders a navigable hyperlink for the enclosed text. See also [Link navigation with BBCodeBlock](Link-navigation-with-BBCodeBlock) |
## Notes
* Every opening tag must be followed by a closing tag.
* BBCode tags can be nested. This snippet renders the text bold and italic: {{[b](b)[i](i)some text[/i](_i)[/b](_b)}}
* Whenever a BBCode parse error occurs, the BBCodeBlock renders the actual BBCode.