# Per-monitor DPI Awareness

Per-monitor DPI awareness, introduced in Windows 8.1, enables an application to scale its window appropriately for the screen it is rendered on. With multiple monitors having different DPI settings, the operation system signals a window when it is dragged to a screen that has a different DPI than the screen it is moving from.

## Support
Prior to Windows 8.1, per-monitor DPI awereness didn't exist, the operation system provided a single system DPI, which WPF automatically supports.

As of release 1.0.6, Modern UI automatically enables per-monitor DPI awareness when supported by the host OS. The new base class **DpiAwareWindow** implements all the necessary functionality for scaling to the current monitor DPI settings. Both ModernWindow and ModernDialog derive from DpiAwareWindow.

## Requirements
For a ModernUI application to support per-monitor DPI awareness there are two requirements:

# Obviously the host OS must be Windows 8.1 or higher. If a ModernUI app is running on an OS not supporting per-monitor DPI awareness, it automatically falls back to SystemDPI awareness, the WPF default setting.
# In order to enable PerMonitorDpiAwareness for a process, it must initially be set to DPI unaware. This can be achieved by adding the following assembly attribute to the AssemblyInfo.cs of your application:
{code:c#}
using System.Windows.Media;
[assembly: DisableDpiAwareness](assembly_-DisableDpiAwareness)
{code:c#}

## DPI API
ModernUI exposes an API that can be used to query the current DPI settings.

### DpiAwareWindow
property **DpiInformation**
Exposes information about the current DPI settings for the window.

event **DpiChanged** and method **OnDpiChanged**
Occurs when the DPI settings changed for the screen that the window is rendered on. Override OnDpiChanged or handle the DpiChanged event to act on DPI changes. You could for instance load high/low DPI image assets.

### ModernUIHelper
Contains helper methods for getting and setting the DPI awareness for the current process.

method **GetDpiAwereness**
Queries the current DPI awareness of the process. Returns DpiUnaware, SystemDpiAware or PerMonitorDpiAware 

method **TrySetPerMonitorDpiAware**
Attempts to set the DPI awareness to PerMonitorDpiAware. When PerMonitorDpiAware is not supported by the host OS, the awareness is set to SystemDpiAware. The initial DPI awareness of the process must be set to DpiUnaware for the operation to succeed. Any failures are silently dropped, the return value signals whether the operation was successful.
This method is used internally by DpiAwareWindow, there is no need to invoke this method explicitly.

ModernUI's implementation of per-monitor DPI awareness is largely based on MSDN article [Developing a Per-Monitor DPI-Aware WPF Application](http://msdn.microsoft.com/en-us/library/windows/desktop/ee308410(v=vs.85).aspx).
