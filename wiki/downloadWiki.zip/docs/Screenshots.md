# Screenshots

Demonstrating what Modern UI for WPF is all about. The screenshots are taken from the demo application included in the Modern UI for WPF download.

![](Screenshots_mui.intro.png)

![](Screenshots_mui.snowflakes.png)

![](Screenshots_mui.hellokitty.png)

![](Screenshots_mui.love.png)

![](Screenshots_mui.layout.png)

![](Screenshots_mui.styles.png)

![](Screenshots_mui.settings.light.png)

![](Screenshots_mui.settings.dark.png)

![](Screenshots_mui.listlayout.dark.png)

![](Screenshots_mui.image.dark.png)

![](Screenshots_mui.msgbox.png)
